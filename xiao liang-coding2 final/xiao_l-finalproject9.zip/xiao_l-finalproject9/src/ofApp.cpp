#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    // Set the width and height of the camera
    camWidth = 640;
    camHeight = 480;
    
    // Initialize the camera
    grabber.setDeviceID(0);
    grabber.setDesiredFrameRate(60);
    grabber.initGrabber(camWidth, camHeight);
    
    // Set pixels and textures
    videoPixels.allocate(camWidth, camHeight, OF_PIXELS_RGB);
    videoTexture.allocate(videoPixels);
    
    // Sets the pixel size of the Mosaic
    pixelSize = 3;
    
    // Form a small circle
    generateCircles();
}

//--------------------------------------------------------------
void ofApp::update(){
    // Update the camera
    grabber.update();
    
    // Renewal circle
    updateCircles();
}

//--------------------------------------------------------------
void ofApp::draw(){
    // Copy the camera pixels into the videoPixels
    if(grabber.isFrameNew()){
        videoPixels = grabber.getPixels();
    }
    
    // Draw the Mosaic effect
    for(int x = 0; x < camWidth; x += pixelSize){
        for(int y = 0; y < camHeight; y += pixelSize){
            ofColor pixelColor = videoPixels.getColor(x, y);
            if(pixelColor.getBrightness() > 128){
                ofSetColor(255, 182, 193); // Light pink
            }
            else{
                ofSetColor(255, 105, 180); // Deep pink
            }
            ofDrawRectangle(x, y, pixelSize, pixelSize);
        }
    }
    
    //Draw a small circle
    ofSetColor(255);
    for(int i = 0; i < numCircles; i++){
        ofDrawCircle(circlePositions[i], circleSizes[i]);
    }
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y){
    // Update the speed of the small circle according to the mouse position
    for(int i = 0; i < numCircles; i++){
        float dist = ofDist(x, y, circlePositions[i].x, circlePositions[i].y);
        circleSpeeds[i] = ofMap(dist, 0, ofGetWidth(), 10, 0);
    }
}

//--------------------------------------------------------------
void ofApp::generateCircles(){
// Generate 100 small circles randomly distributed in the window
 numCircles = 100;
 for(int i = 0; i < numCircles; i++){
 float xPos = ofRandom(ofGetWidth());
 float yPos = ofRandom(-500, 0);
 float size = ofRandom(1, 3);
 circlePositions.push_back(ofVec2f(xPos, yPos));
 circleSpeeds.push_back(ofRandom(1, 10));
 circleSizes.push_back(size);
}
}

//--------------------------------------------------------------
void ofApp::updateCircles(){
// Update the position of the small circle according to the speed
 for(int i = 0; i < numCircles; i++){
 circlePositions[i].y += circleSpeeds[i];
 if(circlePositions[i].y > ofGetHeight() + 100){
// If the circle is outside the window, regenerate it and place it at the top of the window
 float xPos = ofRandom(ofGetWidth());
 float yPos = ofRandom(-100, 0);
 float size = ofRandom(1, 3);
 circlePositions[i].set(xPos, yPos);
 circleSpeeds[i] = ofRandom(1, 100);
 circleSizes[i] = size;
 }
}
}
