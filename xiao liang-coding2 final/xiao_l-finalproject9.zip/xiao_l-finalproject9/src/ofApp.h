#pragma once
#include "ofMain.h"

class ofApp : public ofBaseApp{
public:
    void setup();
    void update();
    void draw();
    void mouseMoved(int x, int y);
    void generateCircles();
    void updateCircles();
    
    ofVideoGrabber grabber;
    int camWidth, camHeight;
    ofPixels videoPixels;
    ofTexture videoTexture;
    int pixelSize;
    
    vector<ofVec2f> circlePositions;
    vector<float> circleSpeeds;
    vector<float> circleSizes;
    int numCircles;
};
